<?php

namespace App\Http\Controllers;

use App\Models\GuestCoupon;
use Illuminate\Http\Request;

class GuestCouponController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\GuestCoupon  $guestCoupon
     * @return \Illuminate\Http\Response
     */
    public function show(GuestCoupon $guestCoupon)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\GuestCoupon  $guestCoupon
     * @return \Illuminate\Http\Response
     */
    public function edit(GuestCoupon $guestCoupon)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\GuestCoupon  $guestCoupon
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GuestCoupon $guestCoupon)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\GuestCoupon  $guestCoupon
     * @return \Illuminate\Http\Response
     */
    public function destroy(GuestCoupon $guestCoupon)
    {
        //
    }
}
